﻿using BlazorRoleBasedAuthApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BlazorRoleBasedAuthApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController(IConfiguration configuration) : ControllerBase
    {
        [HttpPost]
        public async Task<ActionResult<LoginResponseModel>> Login([FromBody]LoginModel model)
        {
            if (ModelState.IsValid) { 
                if(model.Username == "admin" && model.Password == "admin")
                {
                    var token = GenerateJwtToken(model.Username);
                    return Ok(new LoginResponseModel { Token=token});
                }
                return BadRequest();
            }
            return null;
        }

        private string GenerateJwtToken(string username)
        {

            var claims = new[]
            {
                new Claim(ClaimTypes.Name, username),
                new Claim(ClaimTypes.Role, "Admin")
            };

            string secret = configuration.GetValue<string>("Jwt:Secret");
            string issuer = configuration.GetValue<string>("Jwt:Issuer");
            string audience = configuration.GetValue<string>("Jwt:Audience");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.UtcNow.AddHours(2),
                signingCredentials: creds
                );
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
