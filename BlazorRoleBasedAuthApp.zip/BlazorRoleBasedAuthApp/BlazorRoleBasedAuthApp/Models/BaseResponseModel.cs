﻿namespace BlazorRoleBasedAuthApp.Models
{
    public class BaseResponseModel
    {
    }
}
