﻿using Newtonsoft.Json;

namespace CommonAuthApp.Web
{
    public class AuthApiClient(HttpClient httpClient)
    {
        public Task<T> GetFromJsonAsync<T>(string url) 
        { 
            return httpClient.GetFromJsonAsync<T>(url);
        }

        public async Task<T1> PostAsync<T1, T2>(string url, T2 postModel)
        {
            var res = await httpClient.PostAsJsonAsync(url, postModel);
            if (res != null && res.IsSuccessStatusCode)
            {
                return JsonConvert.DeserializeObject<T1>(await res.Content.ReadAsStringAsync());
            }
            return default;
        }
    }
}
