﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonAuthApp.API.Constants
{
    public static class LanguageCodes
    {
        public const string ENGLISH = "en-US";
        public const string FRENCH = "fr-FR";

    }
}
