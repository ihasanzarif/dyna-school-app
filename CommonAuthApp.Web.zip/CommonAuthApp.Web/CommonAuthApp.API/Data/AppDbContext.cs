﻿using CommonAuthApp.API.Models;
using Microsoft.EntityFrameworkCore;

namespace CommonAuthApp.Database
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            
        }

        public DbSet<RegisterUserModel> RegisterUsers { get; set; }
    }
}
